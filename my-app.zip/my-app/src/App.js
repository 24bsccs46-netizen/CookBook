import logo from './images/cookbook_logo.jpeg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Welcome To Cookbook! Your Virtual Kitchen Assistant.
        </p>
        <p style={{ color: "#bc6700", fontSize: "17px", fontWeight: "bold", marginTop: "18px" }}>
  Created By HIBA FATHIMA And Team
</p>
<div style={{ margin: "20px 0", fontSize: "15px", color: "#446d44", fontStyle: "italic" }}>
  “Cooking is like love. It should be entered into with abandon or not at all.” – Harriet Van Horne
</div>

<div style={{ margin: "22px 0", fontSize: "17px", color: "#6b3906", fontWeight: "bold" }}>
  🍲 Recipe of the Day: Paneer Butter Masala
</div>
        <a
          className="App-link"
          href="https://www.allrecipes.com/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Explore Top Recipes
        </a>
      </header>
    </div>
  );
}

export default App;
